/**
 * AI Error Corrector - Frontend JavaScript
 * Handles all user interactions, API calls, and DOM updates
 */

// ========================================
// Configuration
// ========================================
const API_BASE_URL = 'http://localhost:5000/api';
const DEBOUNCE_DELAY = 500;

// ========================================
// DOM Elements
// ========================================
const elements = {
    // Navigation
    navbar: document.querySelector('.navbar'),
    navToggle: document.querySelector('.nav-toggle'),
    navLinks: document.querySelector('.nav-links'),
    
    // Correction Page
    inputText: document.getElementById('inputText'),
    outputText: document.getElementById('outputText'),
    charCount: document.getElementById('charCount'),
    correctBtn: document.getElementById('correctBtn'),
    clearBtn: document.getElementById('clearBtn'),
    copyBtn: document.getElementById('copyBtn'),
    downloadBtn: document.getElementById('downloadBtn'),
    micBtn: document.getElementById('micBtn'),
    autoCorrect: document.getElementById('autoCorrect'),
    confidenceBar: document.getElementById('confidenceBar'),
    confidenceFill: document.getElementById('confidenceFill'),
    confidenceValue: document.getElementById('confidenceValue'),
    errorsList: document.getElementById('errorsList'),
    suggestionsList: document.getElementById('suggestionsList'),
    errorCount: document.getElementById('errorCount'),
    suggestionCount: document.getElementById('suggestionCount'),
    loadingOverlay: document.getElementById('loadingOverlay'),
    loadingStatus: document.getElementById('loadingStatus'),
    exampleBtns: document.querySelectorAll('.example-btn'),
    
    // History Page
    searchHistory: document.getElementById('searchHistory'),
    sortFilter: document.getElementById('sortFilter'),
    clearHistoryBtn: document.getElementById('clearHistoryBtn'),
    historyList: document.getElementById('historyList'),
    totalCorrections: document.getElementById('totalCorrections'),
    totalErrorsFixed: document.getElementById('totalErrorsFixed'),
    todayCorrections: document.getElementById('todayCorrections'),
    historyModal: document.getElementById('historyModal'),
    modalOriginal: document.getElementById('modalOriginal'),
    modalCorrected: document.getElementById('modalCorrected'),
    modalErrors: document.getElementById('modalErrors'),
    closeModal: document.getElementById('closeModal'),
    restoreBtn: document.getElementById('restoreBtn'),
    deleteItemBtn: document.getElementById('deleteItemBtn'),
    
    // Toast
    toast: document.getElementById('toast'),
    toastMessage: document.getElementById('toastMessage'),
};

// ========================================
// State Management
// ========================================
let currentHistory = [];
let selectedHistoryItem = null;
let autoCorrectTimeout = null;

// ========================================
// Utility Functions
// ========================================

/**
 * Debounce function to limit API calls
 */
function debounce(func, wait) {
    return function executedFunction(...args) {
        clearTimeout(autoCorrectTimeout);
        autoCorrectTimeout = setTimeout(() => func.apply(this, args), wait);
    };
}

/**
 * Show toast notification
 */
function showToast(message, type = 'success') {
    const toast = elements.toast;
    const toastMessage = elements.toastMessage;
    
    toastMessage.textContent = message;
    toast.querySelector('i').className = type === 'success' ? 'fas fa-check-circle' : 'fas fa-exclamation-circle';
    
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

/**
 * Show/hide loading overlay
 */
function toggleLoading(show, message = 'Processing your text...') {
    if (show) {
        elements.loadingStatus.textContent = message;
        elements.loadingOverlay.classList.add('active');
    } else {
        elements.loadingOverlay.classList.remove('active');
    }
}

/**
 * Format date for display
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)}d ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

// ========================================
// API Functions
// ========================================

/**
 * Call the correction API
 */
async function correctText(text) {
    if (!text.trim()) return null;
    
    toggleLoading(true, 'Analyzing text...');
    
    try {
        const response = await fetch(`${API_BASE_URL}/correct`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ text }),
        });
        
        if (!response.ok) {
            throw new Error('Failed to correct text');
        }
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Correction error:', error);
        showToast('Failed to correct text. Please try again.', 'error');
        
        // Fallback to local correction if API fails
        return performLocalCorrection(text);
    } finally {
        toggleLoading(false);
    }
}

/**
 * Fetch correction history
 */
async function fetchHistory() {
    try {
        const response = await fetch(`${API_BASE_URL}/history`);
        
        if (!response.ok) {
            throw new Error('Failed to fetch history');
        }
        
        const data = await response.json();
        currentHistory = data.history || [];
        return currentHistory;
    } catch (error) {
        console.error('History fetch error:', error);
        
        // Try to get from localStorage as fallback
        const localHistory = localStorage.getItem('correctionHistory');
        if (localHistory) {
            currentHistory = JSON.parse(localHistory);
            return currentHistory;
        }
        
        return [];
    }
}

/**
 * Delete a history item
 */
async function deleteHistoryItem(id) {
    try {
        await fetch(`${API_BASE_URL}/history/${id}`, {
            method: 'DELETE',
        });
        return true;
    } catch (error) {
        console.error('Delete error:', error);
        
        // Local fallback
        currentHistory = currentHistory.filter(item => item._id !== id);
        localStorage.setItem('correctionHistory', JSON.stringify(currentHistory));
        return true;
    }
}

/**
 * Clear all history
 */
async function clearAllHistory() {
    try {
        await fetch(`${API_BASE_URL}/history`, {
            method: 'DELETE',
        });
        return true;
    } catch (error) {
        console.error('Clear history error:', error);
        
        // Local fallback
        currentHistory = [];
        localStorage.removeItem('correctionHistory');
        return true;
    }
}

// ========================================
// Local Correction (Fallback)
// ========================================

/**
 * Perform local text correction when API is unavailable
 */
function performLocalCorrection(text) {
    const errors = [];
    const suggestions = [];
    let correctedText = text;
    
    // Common spelling mistakes dictionary
    const spellingMistakes = {
        'teh': 'the',
        'thier': 'their',
        'recieve': 'receive',
        'occured': 'occurred',
        'seperate': 'separate',
        'definately': 'definitely',
        'accomodate': 'accommodate',
        'occassion': 'occasion',
        'pharoah': 'pharaoh',
        'truely': 'truly',
        'bizzare': 'bizarre',
        'concious': 'conscious',
    };
    
    // Grammar patterns
    const grammarPatterns = [
        { pattern: /\bi\s+am\b/gi, suggestion: 'I am', type: 'grammar' },
        { pattern: /\bdo\s+not\b/gi, suggestion: "don't", type: 'grammar' },
        { pattern: /\bcan\s+not\b/gi, suggestion: "cannot", type: 'grammar' },
        { pattern: /\bit\s+is\b/gi, suggestion: "it's", type: 'grammar' },
    ];
    
    // Check spelling
    Object.entries(spellingMistakes).forEach(([wrong, right]) => {
        const regex = new RegExp(`\\b${wrong}\\b`, 'gi');
        if (regex.test(correctedText)) {
            const matches = correctedText.match(regex);
            matches.forEach(match => {
                errors.push({
                    type: 'spelling',
                    original: match,
                    suggestion: right,
                    severity: 'medium',
                    message: `Misspelled word: "${match}" should be "${right}"`,
                });
                suggestions.push({
                    original: match,
                    suggestion: right,
                    type: 'spelling',
                });
            });
            correctedText = correctedText.replace(regex, right);
        }
    });
    
    // Check grammar
    grammarPatterns.forEach(({ pattern, suggestion, type }) => {
        if (pattern.test(correctedText)) {
            const matches = correctedText.match(pattern);
            matches.forEach(match => {
                errors.push({
                    type: 'grammar',
                    original: match,
                    suggestion: suggestion,
                    severity: 'low',
                    message: `Grammar: Consider using "${suggestion}"`,
                });
                suggestions.push({
                    original: match,
                    suggestion: suggestion,
                    type: 'grammar',
                });
            });
            correctedText = correctedText.replace(pattern, suggestion);
        }
    });
    
    // Calculate confidence based on number of errors found
    const confidence = Math.max(50, Math.min(98, 100 - (errors.length * 5)));
    
    return {
        original: text,
        corrected: correctedText,
        errors: errors,
        suggestions: suggestions,
        confidence: confidence,
    };
}

// ========================================
// UI Update Functions
// ========================================

/**
 * Update character count
 */
function updateCharCount() {
    if (elements.charCount) {
        elements.charCount.textContent = elements.inputText.value.length;
    }
}

/**
 * Display correction results
 */
function displayResults(data) {
    // Display corrected text
    if (data.corrected) {
        elements.outputText.innerHTML = escapeHtml(data.corrected);
    } else {
        elements.outputText.innerHTML = '<span class="placeholder-text">No corrections needed!</span>';
    }
    
    // Update confidence
    if (data.confidence !== undefined) {
        elements.confidenceBar.style.display = 'flex';
        elements.confidenceFill.style.width = `${data.confidence}%`;
        elements.confidenceValue.textContent = `${data.confidence}%`;
    }
    
    // Display errors
    displayErrors(data.errors || []);
    
    // Display suggestions
    displaySuggestions(data.suggestions || []);
}

/**
 * Display errors in the panel
 */
function displayErrors(errors) {
    elements.errorCount.textContent = errors.length;
    
    if (errors.length === 0) {
        elements.errorsList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-check-circle"></i>
                <p>No errors detected!</p>
            </div>
        `;
        return;
    }
    
    elements.errorsList.innerHTML = errors.map(error => `
        <div class="error-item ${error.severity || 'medium'}">
            <i class="fas fa-exclamation-circle"></i>
            <div class="error-content">
                <div class="error-text">${escapeHtml(error.original)}</div>
                <div class="error-suggestion">${escapeHtml(error.suggestion || '')}</div>
            </div>
            <span class="error-type">${error.type}</span>
        </div>
    `).join('');
}

/**
 * Display suggestions in the panel
 */
function displaySuggestions(suggestions) {
    elements.suggestionCount.textContent = suggestions.length;
    
    if (suggestions.length === 0) {
        elements.suggestionsList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-sparkles"></i>
                <p>No suggestions available</p>
            </div>
        `;
        return;
    }
    
    elements.suggestionsList.innerHTML = suggestions.map(suggestion => `
        <div class="suggestion-item">
            <i class="fas fa-lightbulb"></i>
            <div class="suggestion-content">
                <div class="suggestion-text">
                    <strong>${escapeHtml(suggestion.original)}</strong> 
                    → 
                    <span style="color: var(--success)">${escapeHtml(suggestion.suggestion)}</span>
                </div>
            </div>
        </div>
    `).join('');
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Copy text to clipboard
 */
async function copyToClipboard() {
    const text = elements.outputText.textContent;
    
    try {
        await navigator.clipboard.writeText(text);
        showToast('Copied to clipboard!');
    } catch (err) {
        // Fallback
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToast('Copied to clipboard!');
    }
}

/**
 * Download result as text file
 */
function downloadResult() {
    const text = elements.outputText.textContent;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'corrected-text.txt';
    a.click();
    URL.revokeObjectURL(url);
    showToast('Download started!');
}

// ========================================
// History Functions
// ========================================

/**
 * Load and display history
 */
async function loadHistory() {
    toggleLoading(true, 'Loading history...');
    
    try {
        currentHistory = await fetchHistory();
        renderHistory(currentHistory);
        updateHistoryStats();
    } catch (error) {
        console.error('Error loading history:', error);
        showToast('Failed to load history', 'error');
    } finally {
        toggleLoading(false);
    }
}

/**
 * Render history list
 */
function renderHistory(history) {
    if (!elements.historyList) return;
    
    if (history.length === 0) {
        elements.historyList.innerHTML = `
            <div class="empty-history">
                <div class="empty-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <h3>No History Yet</h3>
                <p>Start correcting text to see your history here</p>
                <a href="correction.html" class="btn btn-primary">
                    <i class="fas fa-wand-magic-sparkles"></i>
                    Start Correcting
                </a>
            </div>
        `;
        return;
    }
    
    elements.historyList.innerHTML = history.map(item => `
        <div class="history-item" data-id="${item._id || item.id}">
            <div class="history-item-content">
                <div class="history-item-original">${escapeHtml(item.input_text || item.original)}</div>
                <div class="history-item-corrected">${escapeHtml(item.corrected_text || item.corrected)}</div>
            </div>
            <div class="history-item-meta">
                <span class="history-item-date">${formatDate(item.timestamp)}</span>
                <span class="history-item-errors">
                    <i class="fas fa-bug"></i>
                    ${item.errors?.length || 0}
                </span>
            </div>
            <div class="history-item-actions">
                <button class="btn-icon" onclick="event.stopPropagation(); viewHistoryItem('${item._id || item.id}')" title="View Details">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn-icon" onclick="event.stopPropagation(); deleteHistoryItemById('${item._id || item.id}')" title="Delete">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        </div>
    `).join('');
    
    // Add click handlers
    document.querySelectorAll('.history-item').forEach(item => {
        item.addEventListener('click', () => {
            viewHistoryItem(item.dataset.id);
        });
    });
}

/**
 * Update history statistics
 */
function updateHistoryStats() {
    const today = new Date().toDateString();
    const todayCount = currentHistory.filter(item => 
        new Date(item.timestamp).toDateString() === today
    ).length;
    
    const totalErrors = currentHistory.reduce((sum, item) => 
        sum + (item.errors?.length || 0), 0
    );
    
    if (elements.totalCorrections) {
        elements.totalCorrections.textContent = currentHistory.length;
        elements.totalErrorsFixed.textContent = totalErrors;
        elements.todayCorrections.textContent = todayCount;
    }
}

/**
 * View history item details
 */
function viewHistoryItem(id) {
    const item = currentHistory.find(h => (h._id || h.id) === id);
    if (!item) return;
    
    selectedHistoryItem = item;
    
    elements.modalOriginal.textContent = item.input_text || item.original;
    elements.modalCorrected.textContent = item.corrected_text || item.corrected;
    elements.modalErrors.textContent = (item.errors || []).map(e => 
        `${e.original} → ${e.suggestion} (${e.type})`
    ).join('\n') || 'No errors found';
    
    elements.historyModal.classList.add('active');
}

/**
 * Delete history item by ID
 */
async function deleteHistoryItemById(id) {
    if (!confirm('Are you sure you want to delete this item?')) return;
    
    await deleteHistoryItem(id);
    currentHistory = currentHistory.filter(item => (item._id || item.id) !== id);
    renderHistory(currentHistory);
    updateHistoryStats();
    showToast('Item deleted');
}

/**
 * Filter history by search
 */
function filterHistory() {
    const searchTerm = elements.searchHistory.value.toLowerCase();
    const sortOrder = elements.sortFilter.value;
    
    let filtered = currentHistory.filter(item => {
        const text = (item.input_text || item.original || '').toLowerCase();
        const corrected = (item.corrected_text || item.corrected || '').toLowerCase();
        return text.includes(searchTerm) || corrected.includes(searchTerm);
    });
    
    // Sort
    filtered.sort((a, b) => {
        const dateA = new Date(a.timestamp);
        const dateB = new Date(b.timestamp);
        return sortOrder === 'newest' ? dateB - dateA : dateA - dateB;
    });
    
    renderHistory(filtered);
}

// ========================================
// Example Texts
// ========================================

const exampleTexts = {
    grammar: "I goes to the store yesterday. He don't know nothing about it. Their going to the party tonight.",
    spelling: "Thier house is very nice. I recieved the letter yesterday. The wether is nice today.",
    code: "function sum(a,b) { return a + b } const x = 10 console.log(x)",
};

// ========================================
// Event Listeners
// ========================================

/**
 * Initialize event listeners
 */
function initEventListeners() {
    // Navigation toggle
    if (elements.navToggle && elements.navLinks) {
        elements.navToggle.addEventListener('click', () => {
            elements.navLinks.classList.toggle('active');
        });
    }
    
    // Scroll navbar effect
    window.addEventListener('scroll', () => {
        if (elements.navbar) {
            if (window.scrollY > 50) {
                elements.navbar.classList.add('scrolled');
            } else {
                elements.navbar.classList.remove('scrolled');
            }
        }
    });
    
    // Correction page
    if (elements.inputText) {
        // Character count
        elements.inputText.addEventListener('input', () => {
            updateCharCount();
            
            // Auto-correct on typing (debounced)
            if (elements.autoCorrect?.checked) {
                debounce(async () => {
                    const text = elements.inputText.value;
                    if (text.length > 10) {
                        const result = await correctText(text);
                        if (result) {
                            displayResults(result);
                        }
                    }
                }, DEBOUNCE_DELAY)();
            }
        });
        
        // Clear input
        if (elements.clearBtn) {
            elements.clearBtn.addEventListener('click', () => {
                elements.inputText.value = '';
                elements.outputText.innerHTML = '<span class="placeholder-text">Your corrected text will appear here...</span>';
                elements.confidenceFill.style.width = '0%';
                elements.confidenceValue.textContent = '0%';
                updateCharCount();
                
                // Reset panels
                elements.errorsList.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-check-circle"></i>
                        <p>No errors detected yet</p>
                    </div>
                `;
                elements.suggestionsList.innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-sparkles"></i>
                        <p>Suggestions will appear here</p>
                    </div>
                `;
                elements.errorCount.textContent = '0';
                elements.suggestionCount.textContent = '0';
            });
        }
        
        // Correct button
        if (elements.correctBtn) {
            elements.correctBtn.addEventListener('click', async () => {
                const text = elements.inputText.value;
                if (!text.trim()) {
                    showToast('Please enter some text to correct', 'error');
                    return;
                }
                
                elements.correctBtn.classList.add('loading');
                const result = await correctText(text);
                elements.correctBtn.classList.remove('loading');
                
                if (result) {
                    displayResults(result);
                }
            });
        }
        
        // Copy button
        if (elements.copyBtn) {
            elements.copyBtn.addEventListener('click', copyToClipboard);
        }
        
        // Download button
        if (elements.downloadBtn) {
            elements.downloadBtn.addEventListener('click', downloadResult);
        }
        
        // Example buttons
        if (elements.exampleBtns) {
            elements.exampleBtns.forEach(btn => {
                btn.addEventListener('click', () => {
                    const type = btn.dataset.example;
                    elements.inputText.value = exampleTexts[type];
                    updateCharCount();
                });
            });
        }
        
        // Voice input (basic implementation)
        if (elements.micBtn) {
            elements.micBtn.addEventListener('click', () => {
                if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
                    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
                    const recognition = new SpeechRecognition();
                    
                    recognition.lang = 'en-US';
                    recognition.start();
                    
                    elements.micBtn.classList.add('recording');
                    
                    recognition.onresult = (event) => {
                        const transcript = event.results[0][0].transcript;
                        elements.inputText.value = transcript;
                        updateCharCount();
                    };
                    
                    recognition.onend = () => {
                        elements.micBtn.classList.remove('recording');
                    };
                } else {
                    showToast('Voice input not supported in this browser', 'error');
                }
            });
        }
    }
    
    // History page
    if (elements.searchHistory) {
        elements.searchHistory.addEventListener('input', filterHistory);
    }
    
    if (elements.sortFilter) {
        elements.sortFilter.addEventListener('change', filterHistory);
    }
    
    if (elements.clearHistoryBtn) {
        elements.clearHistoryBtn.addEventListener('click', async () => {
            if (!confirm('Are you sure you want to clear all history?')) return;
            
            await clearAllHistory();
            renderHistory([]);
            updateHistoryStats();
            showToast('History cleared');
        });
    }
    
    // Modal
    if (elements.closeModal) {
        elements.closeModal.addEventListener('click', () => {
            elements.historyModal.classList.remove('active');
        });
    }
    
    if (elements.historyModal) {
        elements.historyModal.addEventListener('click', (e) => {
            if (e.target === elements.historyModal) {
                elements.historyModal.classList.remove('active');
            }
        });
    }
    
    if (elements.restoreBtn) {
        elements.restoreBtn.addEventListener('click', () => {
            if (selectedHistoryItem) {
                // Store in sessionStorage and navigate
                sessionStorage.setItem('restoreText', selectedHistoryItem.input_text || selectedHistoryItem.original);
                window.location.href = 'correction.html';
            }
        });
    }
    
    if (elements.deleteItemBtn) {
        elements.deleteItemBtn.addEventListener('click', async () => {
            if (selectedHistoryItem) {
                await deleteHistoryItemById(selectedHistoryItem._id || selectedHistoryItem.id);
                elements.historyModal.classList.remove('active');
            }
        });
    }
}

/**
 * Restore text from history
 */
function checkForRestoreText() {
    const restoreText = sessionStorage.getItem('restoreText');
    if (restoreText && elements.inputText) {
        elements.inputText.value = restoreText;
        sessionStorage.removeItem('restoreText');
        updateCharCount();
    }
}

// ========================================
// Initialization
// ========================================

/**
 * Initialize the application
 */
function init() {
    initEventListeners();
    
    // Check if on correction page with restore text
    if (window.location.pathname.includes('correction.html')) {
        checkForRestoreText();
    }
    
    // Load history if on history page
    if (window.location.pathname.includes('history.html') || elements.historyList) {
        loadHistory();
    }
}

// Run on DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

// Export for global access
window.viewHistoryItem = viewHistoryItem;
window.deleteHistoryItemById = deleteHistoryItemById;