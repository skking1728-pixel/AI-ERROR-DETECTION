"""
AI Error Corrector - Flask Backend Application
REST API for text correction with AI-powered error detection
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime, timezone
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import our modules
from backend.ai_logic import AICorrector
from database.mongo_config import MongoDBManager


def get_utc_now():
    """Get current UTC time using timezone-aware datetime (Python 3.12+ compatible)"""
    return datetime.now(timezone.utc)


# Initialize Flask app
app = Flask(__name__)

# Enable CORS for frontend-backend communication
CORS(app, resources={
    r"/api/*": {
        "origins": "*",
        "methods": ["GET", "POST", "PUT", "DELETE"],
        "allow_headers": ["Content-Type"]
    }
})

# Initialize AI Corrector and Database
ai_corrector = AICorrector()
db_manager = MongoDBManager()


# API Routes
@app.route('/api', methods=['GET'])
def index():
    """API health check endpoint"""
    return jsonify({
        'status': 'success',
        'message': 'AI Error Corrector API is running',
        'version': '1.0.0',
        'endpoints': {
            'POST /api/correct': 'Correct text errors',
            'GET /api/history': 'Get correction history',
            'DELETE /api/history': 'Clear all history',
            'DELETE /api/history/<id>': 'Delete specific item'
        }
    })


@app.route('/api/correct', methods=['POST'])
def correct_text():
    """
    POST /api/correct
    Input: { "text": "string" }
    Output: { 
        "original": "string",
        "corrected": "string",
        "errors": [...],
        "suggestions": [...],
        "confidence": number
    }
    """
    try:
        # Get input text from request
        data = request.get_json()
        
        if not data or 'text' not in data:
            return jsonify({
                'status': 'error',
                'message': 'Missing "text" field in request body'
            }), 400
        
        input_text = data['text']
        
        if not input_text or not input_text.strip():
            return jsonify({
                'status': 'error',
                'message': 'Text cannot be empty'
            }), 400
        
        # Perform AI correction
        result = ai_corrector.correct(input_text)
        
        # Save to database
        correction_record = {
            'input_text': input_text,
            'corrected_text': result['corrected'],
            'errors': result['errors'],
            'suggestions': result['suggestions'],
            'confidence': result['confidence'],
            'timestamp': get_utc_now()
        }
        
        # Try to save to MongoDB, but don't fail if unavailable
        try:
            db_manager.save_correction(correction_record)
        except Exception as e:
            print(f"Database save warning: {e}")
        
        return jsonify({
            'status': 'success',
            'data': result
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Internal server error: {str(e)}'
        }), 500


@app.route('/api/history', methods=['GET'])
def get_history():
    """
    GET /api/history
    Returns all previous corrections
    """
    try:
        # Try to get from MongoDB
        try:
            history = db_manager.get_history()
        except Exception as e:
            print(f"Database fetch warning: {e}")
            history = []
        
        # Format history for response
        formatted_history = []
        current_time = get_utc_now()
        
        for item in history:
            timestamp = item.get('timestamp')
            if timestamp is None:
                timestamp_str = current_time.isoformat()
            elif isinstance(timestamp, datetime):
                timestamp_str = timestamp.isoformat()
            else:
                timestamp_str = str(timestamp)
            
            formatted_history.append({
                '_id': str(item.get('_id', '')),
                'input_text': item.get('input_text', ''),
                'corrected_text': item.get('corrected_text', ''),
                'errors': item.get('errors', []),
                'suggestions': item.get('suggestions', []),
                'confidence': item.get('confidence', 0),
                'timestamp': timestamp_str
            })
        
        # Sort by timestamp (newest first)
        formatted_history.sort(key=lambda x: x['timestamp'], reverse=True)
        
        return jsonify({
            'status': 'success',
            'history': formatted_history,
            'count': len(formatted_history)
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Internal server error: {str(e)}'
        }), 500


@app.route('/api/history/<item_id>', methods=['DELETE'])
def delete_history_item(item_id):
    """
    DELETE /api/history/<item_id>
    Delete a specific history item
    """
    try:
        # Try to delete from MongoDB
        try:
            db_manager.delete_item(item_id)
        except Exception as e:
            print(f"Database delete warning: {e}")
        
        return jsonify({
            'status': 'success',
            'message': 'History item deleted successfully'
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Internal server error: {str(e)}'
        }), 500


@app.route('/api/history', methods=['DELETE'])
def clear_history():
    """
    DELETE /api/history
    Clear all correction history
    """
    try:
        # Try to clear from MongoDB
        try:
            db_manager.clear_history()
        except Exception as e:
            print(f"Database clear warning: {e}")
        
        return jsonify({
            'status': 'success',
            'message': 'History cleared successfully'
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Internal server error: {str(e)}'
        }), 500


@app.route('/api/stats', methods=['GET'])
def get_stats():
    """
    GET /api/stats
    Get correction statistics
    """
    try:
        try:
            stats = db_manager.get_stats()
        except Exception as e:
            print(f"Database stats warning: {e}")
            stats = {
                'total_corrections': 0,
                'total_errors_fixed': 0,
                'average_confidence': 0
            }
        
        return jsonify({
            'status': 'success',
            'stats': stats
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Internal server error: {str(e)}'
        }), 500


# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        'status': 'error',
        'message': 'Endpoint not found'
    }), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        'status': 'error',
        'message': 'Internal server error'
    }), 500


# Main entry point
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV', 'production') == 'development'
    
    print(f"Starting AI Error Corrector API on port {port}...")
    print(f"Debug mode: {debug}")
    
    app.run(host='0.0.0.0', port=port, debug=debug)