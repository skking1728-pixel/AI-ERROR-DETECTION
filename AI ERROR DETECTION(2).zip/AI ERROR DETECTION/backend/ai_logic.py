"""
AI Error Corrector - AI Logic Module
NLP-based error detection and correction
"""

import re
import random
from difflib import SequenceMatcher


class AICorrector:
    """
    AI-powered error detection and correction system
    Uses NLP techniques, regex patterns, and dictionary-based checking
    """
    
    def __init__(self):
        # Common English words dictionary (common misspellings)
        self.common_misspellings = {
            'teh': 'the',
            'thier': 'their',
            'recieve': 'receive',
            'occured': 'occurred',
            'seperate': 'separate',
            'definately': 'definitely',
            'accomodate': 'accommodate',
            'occassion': 'occasion',
            'pharoah': 'pharaoh',
            'truely': 'truly',
            'bizzare': 'bizarre',
            'concious': 'conscious',
            'writting': 'writing',
            'goverment': 'government',
            'tommorow': 'tomorrow',
            'tommorrow': 'tomorrow',
            'acheive': 'achieve',
            'acquaintence': 'acquaintance',
            'agressive': 'aggressive',
            'apparant': 'apparent',
            'bulliten': 'bulletin',
            'cemetery': 'cemetery',
            'collegue': 'colleague',
            'committment': 'commitment',
            'conciousness': 'consciousness',
            'concensus': 'consensus',
            'dependant': 'dependent',
            'diFFERENT': 'different',
            'enviroment': 'environment',
            'grammer': 'grammar',
            'hindrence': 'hindrance',
            'immediatly': 'immediately',
            'independant': 'independent',
            'intresting': 'interesting',
            'judgement': 'judgment',
            'knowlege': 'knowledge',
            'neccessary': 'necessary',
            'noticable': 'noticeable',
            'occurrance': 'occurrence',
            'oportunity': 'opportunity',
            'paralell': 'parallel',
            'paramount': 'paramount',
            'pasttime': 'pastime',
            'persistant': 'persistent',
            'posession': 'possession',
            'prefered': 'preferred',
            'priviledge': 'privilege',
            'prrof': 'proof',
            'publically': 'publicly',
            'realy': 'really',
            'reccommend': 'recommend',
            'refered': 'referred',
            'refering': 'referring',
            'relevent': 'relevant',
            'remenant': 'remnant',
            'repitition': 'repetition',
            'resaurant': 'restaurant',
            'resever': 'reserve',
            'respitory': 'respiratory',
            'retreive': 'retrieve',
            'rigram': 'rigor',
            'succesful': 'successful',
            'successfull': 'successful',
            'suprise': 'surprise',
            'temperary': 'temporary',
            'untill': 'until',
            'writen': 'written',
            'yourself': 'yourself',
            # Additional common misspellings
            'wierd': 'weird',
            'weird': 'weird',  # This is correct but kept for reference
            'lonly': 'lonely',
            'truely': 'truly',
            'untill': 'until',
            'begining': 'beginning',
            'beleive': 'believe',
            'belive': 'believe',
            'benifit': 'benefit',
            'calender': 'calendar',
            'concentrate': 'concentrate',
            'concious': 'conscious',
            'deffinitely': 'definitely',
            'effort': 'effort',
            'embarass': 'embarrass',
            'enviroment': 'environment',
            'fluorescent': 'fluorescent',
            'freind': 'friend',
            'gaurd': 'guard',
            'happend': 'happened',
            'happend': 'happened',
            'immedaitely': 'immediately',
            'independant': 'independent',
            'inteesting': 'interesting',
            'littel': 'little',
            'marraige': 'marriage',
            'mispell': 'misspell',
            'mispelled': 'misspelled',
            'neccessary': 'necessary',
            'noticible': 'noticeable',
            'occuring': 'occurring',
            'omon': 'common',
            'oportunity': 'opportunity',
            'orignally': 'originally',
            'picure': 'picture',
            'posession': 'possession',
            'preferance': 'preference',
            'privelege': 'privilege',
            'publically': 'publicly',
            'realy': 'really',
            'recomend': 'recommend',
            'recomended': 'recommended',
            'reffer': 'refer',
            'refered': 'referred',
            'relativ': 'relative',
            'religous': 'religious',
            'restaraunt': 'restaurant',
            'revenue': 'revenue',
            'seperate': 'separate',
            'specialy': 'specially',
            'specify': 'specify',
            'strenght': 'strength',
            'tommorow': 'tomorrow',
            'truely': 'truly',
            'usefull': 'useful',
            'writting': 'writing',
        }
        
        # Grammar patterns to check (unique patterns only)
        self.grammar_patterns = [
            {
                'pattern': r'\bi\s+am\b',
                'suggestion': 'I am',
                'type': 'grammar',
                'severity': 'low',
                'message': 'Subject-verb agreement'
            },
            {
                'pattern': r'\bi\s+goes\b',
                'suggestion': 'I go',
                'type': 'grammar',
                'severity': 'medium',
                'message': 'Subject-verb agreement: Use "go" with "I"'
            },
            {
                'pattern': r'\bi\s+comes\b',
                'suggestion': 'I come',
                'type': 'grammar',
                'severity': 'medium',
                'message': 'Subject-verb agreement: Use "come" with "I"'
            },
            {
                'pattern': r'\bi\s+does\b',
                'suggestion': 'I do',
                'type': 'grammar',
                'severity': 'medium',
                'message': 'Subject-verb agreement: Use "do" with "I"'
            },
            {
                'pattern': r'\bi\s+sees\b',
                'suggestion': 'I see',
                'type': 'grammar',
                'severity': 'medium',
                'message': 'Subject-verb agreement: Use "see" with "I"'
            },
            {
                'pattern': r'\bi\s+knoes\b',
                'suggestion': 'I know',
                'type': 'grammar',
                'severity': 'medium',
                'message': 'Subject-verb agreement'
            },
            {
                'pattern': r'\bdo\s+not\b',
                'suggestion': "don't",
                'type': 'grammar',
                'severity': 'low',
                'message': 'Consider using contraction'
            },
            {
                'pattern': r'\bdoes\s+not\b',
                'suggestion': "doesn't",
                'type': 'grammar',
                'severity': 'low',
                'message': 'Consider using contraction'
            },
            {
                'pattern': r'\bwould\s+of\b',
                'suggestion': 'would have',
                'type': 'grammar',
                'severity': 'medium',
                'message': 'Incorrect auxiliary verb'
            },
            {
                'pattern': r'\bcould\s+of\b',
                'suggestion': 'could have',
                'type': 'grammar',
                'severity': 'medium',
                'message': 'Incorrect auxiliary verb'
            },
            {
                'pattern': r'\bshould\s+of\b',
                'suggestion': 'should have',
                'type': 'grammar',
                'severity': 'medium',
                'message': 'Incorrect auxiliary verb'
            },
            {
                'pattern': r'\balot\b',
                'suggestion': 'a lot',
                'type': 'spelling',
                'severity': 'medium',
                'message': 'Common misspelling'
            },
            {
                'pattern': r'\btheir\s+is\b',
                'suggestion': 'there is',
                'type': 'grammar',
                'severity': 'medium',
                'message': 'Homophone confusion'
            },
            {
                'pattern': r'\btheir\s+are\b',
                'suggestion': 'there are',
                'type': 'grammar',
                'severity': 'medium',
                'message': 'Homophone confusion'
            },
            {
                'pattern': r'\byour\s+welcome\b',
                'suggestion': "you're welcome",
                'type': 'grammar',
                'severity': 'medium',
                'message': 'Homophone confusion'
            },
            {
                'pattern': r'\bits\s+a\b',
                'suggestion': "it's a",
                'type': 'grammar',
                'severity': 'low',
                'message': 'Contraction needed'
            },
        ]
        
        # Code-specific patterns
        self.code_patterns = [
            {
                'pattern': r'console\.log\(',
                'type': 'code',
                'severity': 'low',
                'message': 'Consider removing debug log in production'
            },
            {
                'pattern': r'print\s*\(',
                'type': 'code',
                'severity': 'low',
                'message': 'Python print statement found'
            },
        ]
        
        # Initialize NLP tools (basic implementation)
        self._init_nlp_tools()
    
    def _init_nlp_tools(self):
        """Initialize basic NLP tools"""
        # Common word list for validation (no duplicates)
        self.common_words = {
            'the', 'be', 'to', 'of', 'and', 'a', 'in', 'that', 'have', 'i',
            'it', 'for', 'not', 'on', 'with', 'he', 'as', 'you', 'do', 'at',
            'this', 'but', 'his', 'by', 'from', 'they', 'we', 'say', 'her', 'she',
            'or', 'an', 'will', 'my', 'one', 'all', 'would', 'there', 'their', 'what',
            'so', 'up', 'out', 'if', 'about', 'who', 'get', 'which', 'go', 'me',
            'when', 'make', 'can', 'like', 'time', 'no', 'just', 'him', 'know', 'take',
            'people', 'into', 'year', 'your', 'good', 'some', 'could', 'them', 'see', 'other',
            'than', 'then', 'now', 'look', 'only', 'come', 'its', 'over', 'think', 'also',
            'back', 'after', 'use', 'two', 'how', 'our', 'work', 'first', 'well', 'way',
            'even', 'new', 'want', 'because', 'any', 'these', 'give', 'day', 'most', 'us',
            'is', 'are', 'was', 'were', 'been', 'being', 'has', 'had', 'did', 'does',
            'am', 'been', 'being', 'being',
        }
    
    def correct(self, text):
        """
        Main correction function
        Returns dictionary with original, corrected text, errors, and suggestions
        """
        original = text
        corrected = text
        errors = []
        suggestions = []
        
        # Track unique corrections to avoid duplicates
        seen_corrections = set()
        
        # Step 1: Detect spelling errors
        spelling_result = self.detect_spelling_errors(corrected)
        
        # Add unique errors only
        for error in spelling_result['errors']:
            key = (error['original'].lower(), error['suggestion'].lower())
            if key not in seen_corrections:
                seen_corrections.add(key)
                errors.append(error)
        
        for suggestion in spelling_result['suggestions']:
            key = (suggestion['original'].lower(), suggestion['suggestion'].lower())
            if key not in seen_corrections:
                seen_corrections.add(key)
                suggestions.append(suggestion)
        
        # Apply spelling corrections
        spelling_corrections = {}
        for error in spelling_result['errors']:
            original_word = error['original']
            if original_word not in spelling_corrections:
                spelling_corrections[original_word] = error['suggestion']
        
        for orig, corr in spelling_corrections.items():
            corrected = corrected.replace(orig, corr)
        
        # Step 2: Detect grammar errors
        grammar_result = self.detect_grammar_errors(corrected)
        
        # Add unique errors only
        for error in grammar_result['errors']:
            key = (error['original'].lower(), error['suggestion'].lower())
            if key not in seen_corrections:
                seen_corrections.add(key)
                errors.append(error)
        
        for suggestion in grammar_result['suggestions']:
            key = (suggestion['original'].lower(), suggestion['suggestion'].lower())
            if key not in seen_corrections:
                seen_corrections.add(key)
                suggestions.append(suggestion)
        
        # Apply grammar corrections
        grammar_corrections = {}
        for error in grammar_result['errors']:
            original_text = error['original']
            if original_text not in grammar_corrections:
                grammar_corrections[original_text] = error['suggestion']
        
        for orig, corr in grammar_corrections.items():
            corrected = corrected.replace(orig, corr)
        
        # Step 3: Detect code-related issues
        code_issues = self.detect_code_issues(corrected)
        
        # Calculate confidence score
        confidence = self._calculate_confidence(original, corrected, len(errors))
        
        return {
            'original': original,
            'corrected': corrected,
            'errors': errors,
            'suggestions': suggestions,
            'confidence': confidence
        }
    
    def detect_spelling_errors(self, text):
        """
        Detect spelling errors using dictionary and common misspellings
        """
        errors = []
        suggestions = []
        
        # Check against common misspellings
        words = re.findall(r'\b\w+\b', text)
        
        for word in words:
            lower_word = word.lower()
            
            if lower_word in self.common_misspellings:
                correction = self.common_misspellings[lower_word]
                errors.append({
                    'type': 'spelling',
                    'original': word,
                    'suggestion': correction,
                    'severity': 'medium',
                    'message': f'Misspelled word: "{word}" should be "{correction}"'
                })
                suggestions.append({
                    'original': word,
                    'suggestion': correction,
                    'type': 'spelling'
                })
            # Check for potential errors using pattern matching
            elif not self._is_valid_word(lower_word):
                # Try to find closest match
                closest = self._find_closest_word(lower_word)
                if closest and self._similarity(lower_word, closest) > 0.7:
                    errors.append({
                        'type': 'spelling',
                        'original': word,
                        'suggestion': closest,
                        'severity': 'low',
                        'message': f'Possible misspelling: "{word}" - did you mean "{closest}"?'
                    })
                    suggestions.append({
                        'original': word,
                        'suggestion': closest,
                        'type': 'spelling'
                    })
        
        return {
            'errors': errors,
            'suggestions': suggestions
        }
    
    def detect_grammar_errors(self, text):
        """
        Detect grammar errors using regex patterns
        """
        errors = []
        suggestions = []
        
        for pattern_info in self.grammar_patterns:
            pattern = re.compile(pattern_info['pattern'], re.IGNORECASE)
            
            # Find all matches in text
            matches = list(pattern.finditer(text))
            
            for match in matches:
                original_text = match.group(0)
                
                errors.append({
                    'type': pattern_info['type'],
                    'original': original_text,
                    'suggestion': pattern_info['suggestion'],
                    'severity': pattern_info['severity'],
                    'message': pattern_info['message']
                })
                
                suggestions.append({
                    'original': original_text,
                    'suggestion': pattern_info['suggestion'],
                    'type': pattern_info['type']
                })
        
        return {
            'errors': errors,
            'suggestions': suggestions
        }
    
    def detect_code_issues(self, text):
        """
        Detect code-related issues
        """
        issues = []
        
        for pattern_info in self.code_patterns:
            pattern = re.compile(pattern_info['pattern'])
            
            if pattern.search(text):
                issues.append({
                    'type': 'code',
                    'message': pattern_info['message'],
                    'severity': pattern_info['severity']
                })
        
        return {
            'errors': issues
        }
    
    def suggest_corrections(self, word):
        """
        Provide correction suggestions for a given word
        """
        suggestions = []
        
        # Check common misspellings
        if word.lower() in self.common_misspellings:
            suggestions.append(self.common_misspellings[word.lower()])
        
        # Find closest words
        closest = self._find_closest_word(word.lower())
        if closest:
            suggestions.append(closest)
        
        return list(set(suggestions))  # Remove duplicates
    
    def highlight_errors(self, text, errors):
        """
        Generate highlighted HTML for the text with errors marked
        """
        highlighted = text
        
        for error in errors:
            original = error['original']
            replacement = error.get('suggestion', '')
            
            # Create highlight marker
            severity = error.get('severity', 'medium')
            highlight = f'<mark class="error-{severity}" title="{replacement}">{original}</mark>'
            highlighted = highlighted.replace(original, highlight)
        
        return highlighted
    
    def _calculate_confidence(self, original, corrected, error_count):
        """
        Calculate AI confidence score based on corrections made
        """
        if error_count == 0:
            return 100
        
        # Base confidence
        base = 95
        
        # Reduce based on error count
        reduction = min(40, error_count * 5)
        
        # Check if text was significantly changed
        if original != corrected:
            # Minor reduction for significant changes
            reduction += 2
        
        confidence = max(50, base - reduction)
        
        # Add some randomness for realism
        confidence += random.randint(-3, 3)
        
        # Clamp between 50 and 99
        return max(50, min(99, confidence))
    
    def _is_valid_word(self, word):
        """Check if word is valid using simple heuristics"""
        if len(word) < 3:
            return True
        
        # Check against common words
        if word in self.common_words:
            return True
        
        # Check if all letters (likely a valid English word)
        if word.isalpha():
            return True
        
        # Contains digits (probably valid - version numbers, etc.)
        if any(c.isdigit() for c in word):
            return True
        
        # Contains apostrophe (contractions like "don't")
        if "'" in word:
            return True
        
        return False
    
    def _find_closest_word(self, word):
        """Find closest matching word from common words"""
        if not self.common_words:
            return None
        
        closest = None
        highest_similarity = 0
        
        for common_word in self.common_words:
            # Skip words that are too different in length
            if abs(len(word) - len(common_word)) > 2:
                continue
                
            similarity = self._similarity(word, common_word)
            if similarity > highest_similarity:
                highest_similarity = similarity
                closest = common_word
        
        return closest if highest_similarity > 0.6 else None
    
    def _similarity(self, word1, word2):
        """Calculate similarity between two words"""
        return SequenceMatcher(None, word1, word2).ratio()


# For testing purposes
if __name__ == '__main__':
    corrector = AICorrector()
    
    test_texts = [
        "I goes to the store yesterday.",
        "Thier house is very nice.",
        "I definately want to recieve that.",
        "I would of gone to the party.",
        "This is a test of the AI corrector.",
        "The wether is nice today.",
        "I cant beleive its already tommorrow!",
    ]
    
    print("=" * 60)
    print("AI Error Corrector - Test Results")
    print("=" * 60)
    
    for text in test_texts:
        print(f"\n[Input]  {text}")
        result = corrector.correct(text)
        print(f"[Output] {result['corrected']}")
        print(f"[Errors] {len(result['errors'])} found")
        
        if result['errors']:
            print("[Details]")
            for err in result['errors']:
                print(f"  - {err['type']}: '{err['original']}' -> '{err['suggestion']}'")
        
        print(f"[Confidence] {result['confidence']}%")
        print("-" * 60)