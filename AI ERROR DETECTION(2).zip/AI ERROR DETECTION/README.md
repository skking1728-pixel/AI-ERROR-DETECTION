# AI Error Corrector 🌹

A beautiful, AI-powered error correction web application with a Rose + White glassmorphism design. The system takes user input (text/code), detects errors using AI logic, and provides corrected output with explanations.

![AI Error Corrector](https://img.shields.io/badge/Version-1.0.0-rose)
![Python](https://img.shields.io/badge/Python-3.8+-blue)
![Flask](https://img.shields.io/badge/Flask-2.3.2-lightgrey)
![MongoDB](https://img.shields.io/badge/MongoDB-Ready-green)

## ✨ Features

- **🧠 AI-Powered Correction**: Advanced NLP-based error detection for spelling, grammar, and syntax
- **📝 Real-time Typing**: Auto-correct as you type with debounced API calls
- **🎨 Modern UI**: Rose + White glassmorphism design with smooth animations
- **📱 Responsive**: Works perfectly on mobile and desktop
- **📚 History Tracking**: Save and review all past corrections
- **💾 Export Options**: Copy to clipboard or download as text file
- **🎯 Confidence Score**: Shows AI confidence level for each correction
- **🔍 Error Highlighting**: Visual indicators for error severity (low/medium/high)
- **💡 Smart Suggestions**: Context-aware correction suggestions
- **🎤 Voice Input**: Optional voice input support (browser-dependent)

## 🚀 Quick Start

### Prerequisites

- Python 3.8 or higher
- Node.js (for local development) - optional
- MongoDB (optional - works without it)

### Installation

1. **Clone or download the project**

2. **Install Python dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Start MongoDB (optional)**
   ```bash
   # If you have MongoDB installed locally
   mongod
   ```
   
   Or use MongoDB Atlas cloud - just set the `MONGO_URI` environment variable.

4. **Run the Flask server**
   ```bash
   cd backend
   python app.py
   ```

5. **Open the frontend**
   
   Simply open `frontend/index.html` in your browser, or serve it with a local server:
   ```bash
   # Using Python
   cd frontend
   python -m http.server 8000
   ```
   
   Then visit: `http://localhost:8000`

## 📁 Project Structure

```
AI-ERROR-DETECTION/
├── frontend/
│   ├── index.html          # Home page
│   ├── correction.html     # Error correction page
│   ├── history.html        # Correction history page
│   ├── about.html          # About page
│   ├── style.css           # All styles (Rose theme)
│   └── script.js           # Frontend JavaScript
│
├── backend/
│   ├── app.py              # Flask REST API
│   └── ai_logic.py         # AI correction logic
│
├── database/
│   └── mongo_config.py     # MongoDB configuration
│
├── requirements.txt        # Python dependencies
└── README.md              # This file
```

## 🔌 API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api` | GET | API health check |
| `/api/correct` | POST | Correct text errors |
| `/api/history` | GET | Get correction history |
| `/api/history` | DELETE | Clear all history |
| `/api/history/<id>` | DELETE | Delete specific item |
| `/api/stats` | GET | Get correction statistics |

### Example Request

```bash
curl -X POST http://localhost:5000/api/correct \
  -H "Content-Type: application/json" \
  -d '{"text": "I goes to the store yesterday."}'
```

### Example Response

```json
{
  "status": "success",
  "data": {
    "original": "I goes to the store yesterday.",
    "corrected": "I go to the store yesterday.",
    "errors": [
      {
        "type": "grammar",
        "original": "I goes",
        "suggestion": "I go",
        "severity": "medium",
        "message": "Subject-verb agreement"
      }
    ],
    "suggestions": [
      {
        "original": "I goes",
        "suggestion": "I go",
        "type": "grammar"
      }
    ],
    "confidence": 90
  }
}
```

## 🎨 UI/UX Design

### Color Palette

| Color | Hex | Usage |
|-------|-----|-------|
| Rose 50 | #fff1f2 | Light backgrounds |
| Rose 100 | #ffe4e6 | Cards, hover states |
| Rose 500 | #f43f5e | Primary actions, accents |
| Rose 600 | #e11d48 | Active states |
| White | #ffffff | Main background |

### Design Elements

- **Glassmorphism**: Semi-transparent cards with blur effect
- **Gradients**: Soft rose gradients for visual appeal
- **Animations**: Smooth transitions and micro-interactions
- **Typography**: Clean, modern Poppins font

## 🧠 AI Logic

The AI correction system uses:

1. **Spelling Detection**: Dictionary-based checking with common misspellings
2. **Grammar Analysis**: Regex patterns for common grammar errors
3. **Similarity Matching**: Uses SequenceMatcher for fuzzy word matching
4. **Confidence Calculation**: Based on error count and correction magnitude

### Detected Error Types

- **Spelling**: Common misspellings (teh → the, recieve → receive)
- **Grammar**: Subject-verb agreement, contractions, homophones
- **Code**: Basic code syntax patterns

## 🗄️ Database Schema

### MongoDB Collection: `corrections`

```json
{
  "_id": ObjectId,
  "input_text": "Original text",
  "corrected_text": "Corrected text",
  "errors": [
    {
      "type": "spelling|grammar",
      "original": "Original error",
      "suggestion": "Suggested correction",
      "severity": "low|medium|high",
      "message": "Description"
    }
  ],
  "suggestions": [...],
  "confidence": 95,
  "timestamp": DateTime
}
```

## 🔧 Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `MONGO_URI` | mongodb://localhost:27017 | MongoDB connection string |
| `MONGO_DB` | ai_corrector | Database name |
| `PORT` | 5000 | Server port |
| `FLASK_ENV` | production | development/production |

### Running with Custom MongoDB

```bash
# Using MongoDB Atlas
export MONGO_URI="mongodb+srv://username:password@cluster.mongodb.net/?retryWrites=true&w=majority"
python backend/app.py

# Using custom port
export PORT=3000
python backend/app.py
```

## 🧪 Testing

### Test the AI Logic

```bash
cd backend
python ai_logic.py
```

### Test the API

```bash
# Start server
python app.py

# In another terminal
curl http://localhost:5000/api
```

## 📱 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

### Voice Input

Voice input works in browsers that support the Web Speech API:
- Chrome (Desktop)
- Edge

## 🚀 Deployment

### Using Gunicorn (Production)

```bash
# Install gunicorn
pip install gunicorn

# Run with gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Using Docker

Create a `Dockerfile`:

```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 5000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

Build and run:
```bash
docker build -t ai-corrector .
docker run -p 5000:5000 ai-corrector
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

MIT License - feel free to use this project for any purpose.

## 🙏 Acknowledgments

- Font: [Poppins](https://fonts.google.com/specimen/Poppins)
- Icons: [Font Awesome](https://fontawesome.com)
- Design inspiration: Modern glassmorphism trends

---

Made with ❤️ using Flask, MongoDB, and vanilla HTML/CSS/JS