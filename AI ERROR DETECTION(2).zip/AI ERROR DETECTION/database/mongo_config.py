"""
AI Error Corrector - MongoDB Configuration
Database connection and operations manager
"""

from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
import os
from datetime import datetime, timezone


def get_utc_now():
    """Get current UTC time using timezone-aware datetime"""
    return datetime.now(timezone.utc)


class MongoDBManager:
    """
    MongoDB database manager for storing correction history
    Handles connection, CRUD operations, and error handling
    """
    
    def __init__(self):
        """Initialize MongoDB connection with fallback handling"""
        self.client = None
        self.db = None
        self.collection = None
        self._connected = False
        
        # Try to connect to MongoDB
        self._connect()
    
    def _connect(self):
        """Establish MongoDB connection"""
        try:
            # Get MongoDB connection string from environment
            mongo_uri = os.environ.get('MONGO_URI', 'mongodb://localhost:27017')
            db_name = os.environ.get('MONGO_DB', 'ai_corrector')
            
            # Create MongoDB client
            self.client = MongoClient(
                mongo_uri,
                serverSelectionTimeoutMS=5000,  # 5 second timeout
                connectTimeoutMS=5000,
                maxPoolSize=10
            )
            
            # Select database and collection
            self.db = self.client[db_name]
            self.collection = self.db['corrections']
            
            # Test connection
            self.client.admin.command('ping')
            
            self._connected = True
            print(f"[OK] MongoDB connected successfully to {db_name}")
            
        except (ConnectionFailure, ServerSelectionTimeoutError) as e:
            print(f"[!] MongoDB connection failed: {e}")
            print("  Running in offline mode - corrections will not be saved to database")
            self._connected = False
            
        except Exception as e:
            print(f"[!] MongoDB initialization error: {e}")
            self._connected = False
    
    def is_connected(self):
        """Check if MongoDB is connected"""
        return self._connected
    
    def save_correction(self, correction_data):
        """
        Save a correction record to the database
        
        Args:
            correction_data: Dictionary containing correction details
                - input_text: Original text
                - corrected_text: Corrected text
                - errors: List of errors found
                - suggestions: List of suggestions
                - confidence: AI confidence score
                - timestamp: DateTime object
        """
        if not self._connected:
            return None
        
        try:
            # Ensure timestamp is a datetime object with timezone
            if 'timestamp' in correction_data:
                ts = correction_data['timestamp']
                if isinstance(ts, str):
                    # Try to parse ISO format string
                    try:
                        correction_data['timestamp'] = datetime.fromisoformat(ts.replace('Z', '+00:00'))
                    except ValueError:
                        correction_data['timestamp'] = get_utc_now()
                elif not isinstance(ts, datetime):
                    correction_data['timestamp'] = get_utc_now()
                # Ensure timezone-aware
                elif ts.tzinfo is None:
                    correction_data['timestamp'] = ts.replace(tzinfo=timezone.utc)
            
            # Insert document
            result = self.collection.insert_one(correction_data)
            return str(result.inserted_id)
            
        except Exception as e:
            print(f"Error saving correction: {e}")
            return None
    
    def get_history(self, limit=100):
        """
        Retrieve correction history
        
        Args:
            limit: Maximum number of records to return (default: 100)
            
        Returns:
            List of correction records
        """
        if not self._connected:
            return []
        
        try:
            cursor = self.collection.find().sort('timestamp', -1).limit(limit)
            return list(cursor)
            
        except Exception as e:
            print(f"Error fetching history: {e}")
            return []
    
    def get_item_by_id(self, item_id):
        """
        Get a specific correction by ID
        
        Args:
            item_id: MongoDB document ID
            
        Returns:
            Correction record or None
        """
        if not self._connected:
            return None
        
        try:
            from bson import ObjectId
            return self.collection.find_one({'_id': ObjectId(item_id)})
        except Exception as e:
            print(f"Error fetching item: {e}")
            return None
    
    def delete_item(self, item_id):
        """
        Delete a specific correction record
        
        Args:
            item_id: MongoDB document ID
            
        Returns:
            Boolean indicating success
        """
        if not self._connected:
            return False
        
        try:
            from bson import ObjectId
            result = self.collection.delete_one({'_id': ObjectId(item_id)})
            return result.deleted_count > 0
        except Exception as e:
            print(f"Error deleting item: {e}")
            return False
    
    def clear_history(self):
        """
        Clear all correction history
        
        Returns:
            Boolean indicating success
        """
        if not self._connected:
            return False
        
        try:
            result = self.collection.delete_many({})
            print(f"Cleared {result.deleted_count} records from history")
            return True
        except Exception as e:
            print(f"Error clearing history: {e}")
            return False
    
    def get_stats(self):
        """
        Get correction statistics
        
        Returns:
            Dictionary with statistics
        """
        if not self._connected:
            return {
                'total_corrections': 0,
                'total_errors_fixed': 0,
                'average_confidence': 0
            }
        
        try:
            # Total corrections
            total = self.collection.count_documents({})
            
            # Total errors fixed (sum of all errors in all corrections)
            pipeline = [
                {'$project': {'error_count': {'$size': {'$ifNull': ['$errors', []]}}}},
                {'$group': {'_id': None, 'total': {'$sum': '$error_count'}}}
            ]
            result = list(self.collection.aggregate(pipeline))
            total_errors = result[0]['total'] if result else 0
            
            # Average confidence
            pipeline = [
                {'$match': {'confidence': {'$exists': True}}},
                {'$group': {'_id': None, 'avg_confidence': {'$avg': '$confidence'}}}
            ]
            result = list(self.collection.aggregate(pipeline))
            avg_confidence = round(result[0]['avg_confidence'], 1) if result else 0
            
            return {
                'total_corrections': total,
                'total_errors_fixed': total_errors,
                'average_confidence': avg_confidence
            }
            
        except Exception as e:
            print(f"Error getting stats: {e}")
            return {
                'total_corrections': 0,
                'total_errors_fixed': 0,
                'average_confidence': 0
            }
    
    def search_history(self, search_term):
        """
        Search history by text content
        
        Args:
            search_term: Search string
            
        Returns:
            List of matching records
        """
        if not self._connected:
            return []
        
        try:
            query = {
                '$or': [
                    {'input_text': {'$regex': search_term, '$options': 'i'}},
                    {'corrected_text': {'$regex': search_term, '$options': 'i'}}
                ]
            }
            cursor = self.collection.find(query).sort('timestamp', -1)
            return list(cursor)
        except Exception as e:
            print(f"Error searching history: {e}")
            return []
    
    def close(self):
        """Close MongoDB connection"""
        if self.client:
            self.client.close()
            print("MongoDB connection closed")


# MongoDB schema for reference:
# {
#     "_id": ObjectId,
#     "input_text": String,
#     "corrected_text": String,
#     "errors": [
#         {
#             "type": String,
#             "original": String,
#             "suggestion": String,
#             "severity": String,
#             "message": String
#         }
#     ],
#     "suggestions": [
#         {
#             "original": String,
#             "suggestion": String,
#             "type": String
#         }
#     ],
#     "confidence": Number,
#     "timestamp": DateTime
# }


# For testing
if __name__ == '__main__':
    # Test database connection
    db = MongoDBManager()
    
    if db.is_connected():
        # Test save
        test_record = {
            'input_text': 'Test input text',
            'corrected_text': 'Corrected text',
            'errors': [{'type': 'test', 'original': 'test', 'suggestion': 'corrected'}],
            'suggestions': [],
            'confidence': 95,
            'timestamp': get_utc_now()
        }
        
        record_id = db.save_correction(test_record)
        print(f"Saved test record: {record_id}")
        
        # Test get history
        history = db.get_history()
        print(f"Total records: {len(history)}")
        
        # Test stats
        stats = db.get_stats()
        print(f"Stats: {stats}")
        
        # Test clear
        db.clear_history()
        print("History cleared")
    
    else:
        print("MongoDB not connected - running in offline mode")
    
    db.close()